#include <iostream> 
#include <string>
using namespace std;

int main() {
// variable itteration
  int numbers[7]= {1,2,3,4,5,6,3};
bool duplicationFound = false;
  for (int i = 0; i < 7; i++){
    for (int j = i + 1; j < 7; j++)
    if numbers [i] = numbers [j]{
      duplicationFound = true;
      cout << "Duplication fund of " << numbers [i] << endl;
      break;
    }
    if (duplicationFound)
  break;
  
  }

  
  
      
      
  
  if (duplicationFound){
  cout << "No duplacites found" << endl;"
  return 0; 
  

    }