#include <iostream> 
#include <string>
using namespace std;

int main() {

int numbers [8] = {20,8,5,2,35,7,5,4};
int max =numbers [0];
int min = numbers [0];

  for(int i = 0; i < 8; i++){
    if (numbers [i]>max){
      max = numbers [i];
    }
  }
for (int i = 0; i < 8; i++){
  if (numbers [i]<min){
    min = numbers [i];
  }
}
cout << "The maximum number is" << max << endl ;
cout << "The minimum number is" << min << endl ;
  return 0; 

    }